package mycui

// WinMain windows main loop
func WinMain() {
	OnInitDialog()
}
