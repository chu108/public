package dlg

// WinMain windows main loop
func WinMain() {
	OnInitDialog()
}
